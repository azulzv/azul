<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../bootstrap-5/css/bootstrap.min.css">
  <title>Perkenalan PHP</title>

  <style>
  body {
    font-family: 'Poppins';
    font-weight: 600;
    background: #ecf0f3;
  }

  .card {
    background: #ecf0f3;
    box-shadow: 4px 4px 10px #cbced1,
      -4px -4px 10px #fff;
    border-color: #fff;
  }
  </style>
</head>

<body>

  <!-- Praktikum Pemrograman PHP 02 -->
  <div class="container mt-5" style="width: 550px;">
    <div class="card">
      <div class="card-body text-center text-black p-2 rounded-3">
        <?php echo "Belajar Pemrograman PHP itu Menyenangkan dan Mudah"; ?>
      </div>
    </div>
  </div>
  <!-- Praktikum 02 Ends -->

  <script src="../bootstrap-5/js/bootstrap.bundle.min.js"></script>
</body>

</html>