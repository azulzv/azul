<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Meta Tags -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="../bootstrap-5/css/bootstrap.min.css">

  <!-- Bootstrap 5 Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

  <!-- Title Website -->
  <title>Perkenalan PHP</title>

  <!-- CSS Custome -->
  <style>
  body {
    font-family: 'Poppins';
    background: #ecf0f3;
  }

  .card {
    background: #ecf0f3;
    box-shadow: 4px 4px 10px #cbced1,
      -4px -4px 10px #fff;
    border-color: #fff;
  }

  .form-control,
  .form-select {
    background: rgba(255, 255, 255, .3);
  }
  </style>
</head>

<body>
  <!-- PHP Starts -->
  <?php 
  
  $nama = $_POST['nama'];
  $nim = $_POST['nim'];
  $jur = $_POST['jurusan'];
  $alamat = $_POST['alamat'];
  
  ?>
  <!-- PHP Ends -->

  <!-- Praktikum Pemrograman PHP 03 -->
  <div class="container mt-5" style="width: 550px;">
    <div class="card rounded">
      <div class="card-header text-center d-flex justify-content-center pt-2 pb-0 bg-info bg-gradient">
        <img src="../img/USM.png" alt="logo-usm" style="height: 35px;">
        <h3 class="ms-2">UNIVERSITAS SEMARANG</h3>
      </div>
      <div class="row g-0 py-3 px-4">
        <div class="col-md-4 me-1">
          <img src="../img/User.png" class="img rounded-3" alt="image-profile" style="width: 160px; height: 160px;">
          <img src="../img/barcode.png" class="m-3" alt="barcode" style="width: 125px;">
        </div>
        <div class="card-title col-md-6 ms-4">
          <h6 class="text-left fw-bold">KARTU IDENTITAS / KTM<i class="bi bi-upc-scan ms-3"></i></h6>
          <hr>
          <p class="card-text">
            <?= $nama ?>
            <?= $nim ?> <br>
            <?= $jur ?> <br>
            <?= $alamat ?>
          </p>
          <a href="04_exam.php" class="btn btn-sm btn-danger position-absolute bottom-0 end-0 m-3"><i
              class="bi bi-box-arrow-left me-2"></i>back</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Praktikum 03 Ends -->

  <script src="../bootstrap-5/js/bootstrap.bundle.min.js"></script>
</body>

</html>