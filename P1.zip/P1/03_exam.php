<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../bootstrap-5/css/bootstrap.min.css">
  <title>Perkenalan PHP</title>

  <style>
  body {
    font-family: 'Poppins';
    background: #ecf0f3;
  }

  .card {
    background: #ecf0f3;
    box-shadow: 4px 4px 10px #cbced1,
      -4px -4px 10px #fff;
    border-color: #fff;
    line-height: 30px;
  }

  span {
    background: rgba(255, 255, 0, .2);
    padding: 0 2px;
    border-radius: 3px;
  }
  </style>
</head>

<body>

  <!-- PHP Starts -->
  <?php 
  
  $nama = "Adya Abdu Azizul Hakim";
  $nim = "G.211.21.0077";
  $fak = "Fakultas Teknologi Informasi dan Komunikasi";
  $jur = "Teknik Informatika";
  $univ = "Universitas Semarang";
  
  ?>
  <!-- PHP Ends -->

  <!-- Praktikum Pemrograman PHP 03 -->
  <div class="container mt-5" style="width: 500px;">
    <div class="card">
      <div class="card-header fw-bold text-center">
        Profile Saya
      </div>
      <div class="card-body text-center text-black p-2 rounded-3">
        <div class="card-text px-3 pt-1">
          Hallo Semua, Perkenalkan nama saya
          <span><?= $nama ?></span> dengan NIM
          <span><?= $nim?></span>. Saya merupakan seorang mahasiswa dari
          <span><?= $fak ?></span> dengan jurusan
          <span><?= $jur ?></span> di
          <span><?= $univ ?></span>, Jawa Tengah.
        </div>
        <footer class="blockquote-footer mt-4">Belajar PHP itu Mudah dan Menyenangkan, bukan?</footer>
      </div>
    </div>
  </div>
  <!-- Praktikum 03 Ends -->

  <script src="../bootstrap-5/js/bootstrap.bundle.min.js"></script>
</body>

</html>